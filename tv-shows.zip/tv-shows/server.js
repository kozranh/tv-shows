const express = require('express');
const bodyParser = require('body-parser')
const path = require('path');
const mongoose = require('mongoose');
const app = express();

app.use(express.static(path.join(__dirname, 'build')));
app.use(bodyParser());

mongoose.connect('mongodb+srv://book-app:1qB3D0UrM5sBVsP3@cluster0-aujnd.mongodb.net/tv_shows?retryWrites=true&w=majority', {useNewUrlParser: true});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("we're connected!");
});

const Show = mongoose.model('Show', new mongoose.Schema({
  user_id: String,
  image: {
    medium: String
  },
  name: String,
  language: String,
  type: String,
  premiered: String,
  network: {
    name: String
  },
  externals: {
    imdb: String
  }
}));

const User = mongoose.model('User', new mongoose.Schema({
  name: String,
  password: String
}));

app.post('/login', (req, res, next) => {
  User.findOne({
    name: req.body.username
  }, (err, response) => {
    if (err || !response || response.password != req.body.password) {
      console.error("login error: ", err);
      return next(err);
    }

    console.log("login response: ", response);
    return res.send(response);
  });
});


app.post('/api/shows', (req, res, next) => {
  var newShow = new Show(req.body);
  
  newShow.save((err, newShow) => {
    if (err) {
      console.error(err);
      return next(err);
    }
      
    console.log("Book is saved");
    return res.send(newShow);
  });
});

app.get('/api/:user_id/shows', (req, res, next) => {
  Show.find({
    user_id: req.params.user_id
  }, (err, shows) => {
    if (err) {
      console.error(err);
      return next(err);
    }

    console.log("all shows: ", shows);
    return res.send(shows);
  });
});

app.delete('/api/books/:id', (req, res, next) => {
  Book.deleteOne({ _id: req.params.id }, (err, response) => {
    if (err) {
      console.error(err);
      return next(err);
    }

    console.log("response: ", response);
    return res.send(response);
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.listen(process.env.PORT || 8080);