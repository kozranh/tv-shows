import React, { useState } from "react";
import axios from "axios";

import "./login.css";

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      errorMsg: ""
    };

    this.onInputChange = this.onInputChange.bind(this);
    this.onSubmitHandler = this.onSubmitHandler.bind(this);
  }

  onInputChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  onSubmitHandler(e) {
    e.preventDefault();

    axios.post('/login', {
      username: this.state.username,
      password: this.state.password
    }).then(response => {
      console.log(response);
      localStorage.setItem('user', JSON.stringify(response.data));
      this.props.onLoginHandler(response.data);
    }).catch(error => {
      console.log(error);
      this.setState({
        errorMsg: "Invalid username or password"
      });
    });
  }

  render() {
    let {username, password, errorMsg} = this.state;
    return (
      <div className="Login">
        <h1>Login</h1>
        <form className="form">
          <div className="form-group mx-sm-3 mb-2">
            <input type="text" className="form-control"
              placeholder="Username"
              name="username"
              value={username}
              onChange={this.onInputChange} />
          </div>
          <div className="form-group mx-sm-3 mb-2">
            <input type="password" className="form-control"
              placeholder="Password"
              name="password"
              value={password}
              onChange={this.onInputChange} />
          </div>
          <div className="text-red">{errorMsg}</div>
          <button type="submit" className="btn btn-info mb-2" 
            onClick={this.onSubmitHandler}>Login</button>
        </form>
      </div>
    );
  }
}

export default Login;
