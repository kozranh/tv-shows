import React, { useState, useEffect } from "react";
import axios from "axios";
import Login from "./Login/login";

import "./App.css";

const noImageUrl = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9InllcyI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMjQyIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDI0MiAyMDAiIHByZXNlcnZlQXNwZWN0UmF0aW89Im5vbmUiPjwhLS0KU291cmNlIFVSTDogaG9sZGVyLmpzLzEwMCV4MjAwCkNyZWF0ZWQgd2l0aCBIb2xkZXIuanMgMi42LjAuCkxlYXJuIG1vcmUgYXQgaHR0cDovL2hvbGRlcmpzLmNvbQooYykgMjAxMi0yMDE1IEl2YW4gTWFsb3BpbnNreSAtIGh0dHA6Ly9pbXNreS5jbwotLT48ZGVmcz48c3R5bGUgdHlwZT0idGV4dC9jc3MiPjwhW0NEQVRBWyNob2xkZXJfMTZlMDkxOTIyNmYgdGV4dCB7IGZpbGw6I0FBQUFBQTtmb250LXdlaWdodDpib2xkO2ZvbnQtZmFtaWx5OkFyaWFsLCBIZWx2ZXRpY2EsIE9wZW4gU2Fucywgc2Fucy1zZXJpZiwgbW9ub3NwYWNlO2ZvbnQtc2l6ZToxMnB0IH0gXV0+PC9zdHlsZT48L2RlZnM+PGcgaWQ9ImhvbGRlcl8xNmUwOTE5MjI2ZiI+PHJlY3Qgd2lkdGg9IjI0MiIgaGVpZ2h0PSIyMDAiIGZpbGw9IiNFRUVFRUUiLz48Zz48dGV4dCB4PSI4OS44NTE1NjI1IiB5PSIxMDUuMSI+MjQyeDIwMDwvdGV4dD48L2c+PC9nPjwvc3ZnPg==";
let API_URL = `http://api.tvmaze.com/search/shows`;

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTerm: "",
      shows: [],
      showFavs: false,
      user: localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')) : null
    };

    this.onInputChange = this.onInputChange.bind(this);
    this.onSubmitHandler = this.onSubmitHandler.bind(this);
    this.onLoginHandler = this.onLoginHandler.bind(this);
    this.onLogoutHandler = this.onLogoutHandler.bind(this);
    this.addToFav = this.addToFav.bind(this);
    this.viewFav = this.viewFav.bind(this);
    this.changeViewToSearch = this.changeViewToSearch.bind(this);
  }

  onInputChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  onLoginHandler(user) {
    this.setState({
      user
    });
  }

  onLogoutHandler() {
    localStorage.removeItem('user');
    this.setState({
      showFavs: false,
      searchTerm: "",
      user: null,
      shows: []
    });
  }

  changeViewToSearch(){
    this.setState({
      showFavs: false,
      searchTerm: "",
      shows: []
    });
  }

  async viewFav(e) {
    e.preventDefault();

    const result = await axios.get(`/api/${this.state.user._id}/shows`);
    this.setState({
      shows: result.data.map(show => {
        return {show}
      }),
      showFavs: true
    });
  }

  async addToFav(show, e) {
    e.preventDefault();

    axios.post('/api/shows', {
      user_id: this.state.user._id,
      image: {
        medium: show.image && show.image.medium
      },
      name: show.name,
      language: show.language,
      type: show.type,
      premiered: show.premiered,
      network: {
        name: show.network && show.network.name
      },
      externals: {
        imdb: show.externals && show.externals.imdb
      }
    }).then(response => {
      alert("Done! Added to Fav");
    }).catch(error => {
      alert("Error while adding to fav");
    });
  }

  async onSubmitHandler(e) {
    e.preventDefault();
    const result = await axios.get(`${API_URL}?q=${this.state.searchTerm}`);
    this.setState({
      shows: result.data
    });
  }

  render() {
    let { searchTerm, shows, user, showFavs } = this.state;
    return (
      <section>
        {
          !user ?
            <Login onLoginHandler={this.onLoginHandler} /> :
            <div>
              <nav className="navbar navbar-inverse">
                <div className="container-fluid">
                  <div className="navbar-header">
                    <a className="navbar-brand" href="#">Welcome, {user.name}</a>
                  </div>

                  <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul className="nav navbar-nav navbar-right">
                      <li>
                        <a href="#" onClick={this.changeViewToSearch}>Search Shows</a>
                      </li>
                      <li>
                        <a href="#" onClick={this.viewFav}>View Favourite</a>
                      </li>
                      <li>
                        <a href="#" onClick={this.onLogoutHandler}>Logout</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </nav>

              {
                !showFavs && (
                  <div className="text-center">
                    <h1>Search for Shows</h1>
                    <form className="form-inline">
                      <div className="form-group mx-sm-3 mb-2">
                        <input type="text" className="form-control"
                          placeholder="GOT, Friends etc"
                          name="searchTerm"
                          value={searchTerm}
                          onChange={this.onInputChange} />
                      </div>
                      <button type="submit" className="btn btn-info mb-2" onClick={this.onSubmitHandler}>Search</button>
                    </form>
                  </div>
                )
              }

              {
                shows.length == 0 ?
                <div class="text-center">No data</div> : 
                (
                  <div className="row">
                    {shows.map((entry, index) => {
                      let { show } = entry;
                      return (
                        <div key={index} className="col-sm-6 col-md-2">
                          <div className="thumbnail">
                            <img
                              alt={show.name + 'image'}
                              src={(show.image && show.image.medium) || noImageUrl}
                              style={{ height: '287px' }} />
                            <div className="caption">
                              <b>{show.name}</b>
                              <div><i>Language:</i> {show.language}</div>
                              <div><i>Type:</i> {show.type}</div>
                              <div><i>Premiered:</i> {show.premiered}</div>
                              <div><i>Network:</i> {show.network && show.network.name}</div>
                              <a target="_blank" href={"http://www.imdb.com/title/" + show.externals.imdb}>View on IMDB</a>
                              <p>
                                <a href="#" className="btn btn-primary" role="button"
                                  onClick={this.addToFav.bind(this, show)}>Add To Favourite</a>
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )
              }
            </div>
        }
      </section>
    );
  }
}

export default App;
