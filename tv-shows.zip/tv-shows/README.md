Steps to run the project on local machine

    1. npm install
    2. open terminal, go to current directory and run command "npm run start"
    3. open another terminal, go to current directory and run command "node server.js"
    4. open browser, enter url as localhost:3000


user Credentials
    1. username - kozran
        password - kozran

    2. username - pushkar
        password - pushkar